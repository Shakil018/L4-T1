#include <iostream>
#include <vector>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <windows.h>
#include <GL/glut.h>
#include "1705018_Header.hpp"
#include "bitmap_image.hpp"

using namespace std;

#define pi (2 * acos(0.0))
#define INF numeric_limits<double>::infinity()
#define INF2 10000000

ifstream inputFile;
ofstream outputFile;

int myCounter = 0;

double cameraHeight;
double cameraAngle;
int drawgrid;
int drawaxes;
double scaling = 1.0;
int windowHeight = 500, windowWidth = 500;
double angle, viewAngle;

Vector3D up, Right, looking;

extern int recursionDepth;
extern Vector3D cameraPos;
extern vector<Object *> allObjects;
extern vector<PointLight> allPointLights;
extern vector<SpotLight> allSpotLights;

int numOfImages = 0, numOfObjects = 0;
int numOfPointLights = 0, numOfSpotLights = 0;
int imageWidthPixel = 0, imageHeightPixel = 0;

void drawAxes()
{
    if (drawaxes == 1)
    {
        glColor3f(1.0, 1.0, 1.0);
        glBegin(GL_LINES);
        {
            glVertex3f(300, 0, 0);
            glVertex3f(-300, 0, 0);

            glVertex3f(0, -300, 0);
            glVertex3f(0, 300, 0);

            glVertex3f(0, 0, 300);
            glVertex3f(0, 0, -300);
        }
        glEnd();
    }
}

void setColorCoeffs(Object *obj)
{

    Color tempColor;
    CoEfficients coeff;
    int shine;

    inputFile >> tempColor.r_value >> tempColor.g_value >> tempColor.b_value;
    inputFile >> coeff.ambient >> coeff.diffuse >> coeff.specular >> coeff.reflection;
    inputFile >> shine;

    obj->setColor(tempColor);
    obj->setCoEfficients(coeff);
    obj->setShine(shine);
}

void inputTriangle()
{
    Vector3D edge1, edge2, edge3;
    inputFile >> edge1.x >> edge1.y >> edge1.z;
    inputFile >> edge2.x >> edge2.y >> edge2.z;
    inputFile >> edge3.x >> edge3.y >> edge3.z;

    Object *basePointer = new Triangle(edge1, edge2, edge3);

    setColorCoeffs(basePointer);

    allObjects.push_back(basePointer);
    basePointer = NULL;
}

void inputSphere()
{
    Vector3D center;
    double radius;

    inputFile >> center.x >> center.y >> center.z;
    inputFile >> radius;

    Object *basePointer = new Sphere(center, radius, 30, 60);

    setColorCoeffs(basePointer);

    allObjects.push_back(basePointer);
    basePointer = NULL;
}

void inputObject()
{
    Vector3D reference_point;
    double len, width, height;

    QuadricSurfaceCoefficients coeffs;

    inputFile >> coeffs.A >> coeffs.B >> coeffs.C >> coeffs.D >> coeffs.E >> coeffs.F >> coeffs.G >> coeffs.H >> coeffs.I >> coeffs.J;
    inputFile >> reference_point.x >> reference_point.y >> reference_point.z;
    inputFile >> len >> width >> height;

    Object *basePointer = new QuadricSurface(len, width, height, coeffs, reference_point);
    setColorCoeffs(basePointer);

    allObjects.push_back(basePointer);
    basePointer = NULL;
}

void inputPointLight()
{
    PointLight tempLight;

    inputFile >> tempLight.light_position.x >> tempLight.light_position.y >> tempLight.light_position.z;
    inputFile >> tempLight.color.r_value >> tempLight.color.g_value >> tempLight.color.b_value;

    allPointLights.push_back(tempLight);
}

void inputSpotLight()
{
    PointLight tempLight;

    inputFile >> tempLight.light_position.x >> tempLight.light_position.y >> tempLight.light_position.z;
    inputFile >> tempLight.color.r_value >> tempLight.color.g_value >> tempLight.color.b_value;

    SpotLight tempSpot;

    tempSpot.point_light = tempLight;

    inputFile >> tempSpot.light_direction.x >> tempSpot.light_direction.y >> tempSpot.light_direction.z;

    inputFile >> tempSpot.cutoff_angle;

    allSpotLights.push_back(tempSpot);
}

bool isIntNumber(const string &num_str)
{
    for (char const &c : num_str)
    {
        if (!isdigit(c))
            return false;
    }
    return true;
}

void loadData()
{
    string fileName;

    cout << "insert file name: ";
    cin >> fileName;
    inputFile.open("G:/VARSITY/CSE 409 - COMPUTER GRAPHICS/LAB/OFFLINE_3/CODE/RAY_TRACING_FINAL/RAY_FINAL/input/" + fileName + ".txt");
    // inputFile.open("../input/" + fileName + ".txt");

    if (!(inputFile.is_open()))
    {
        cout << "input file open failed" << endl;
        exit(1);
    }

    // cout << "file opened" << endl;

    inputFile >> recursionDepth >> imageWidthPixel;

    imageHeightPixel = imageWidthPixel;

    inputFile >> numOfObjects;

    string objectType = "";

    bool firstLight = false;

    for (int i = 0; i < numOfObjects + 2; i++)
    {
        // cout << "inside input for loop" << endl;

        inputFile >> objectType;

        if (objectType == "sphere")
        {
            // cout << "inputting sphere" << endl;
            inputSphere();
            // cout << "sphere input done" << endl;
        }
        else if (objectType == "triangle")
        {
            // cout << "inputting triangle" << endl;

            inputTriangle();
            // cout << "triangle input done" << endl;
        }
        else if (objectType == "general")
        {
            // cout << "inputting general" << endl;
            inputObject();
            // cout << "general input done" << endl;
        }
        else
        {
            // cout << "inside else" << endl;

            if (!isIntNumber(objectType))
            {
                cout << "object type not available" << endl;
                break;
            }

            // cout << "input is number" << endl;

            if (i == numOfObjects)
            {
                numOfPointLights = atoi(objectType.c_str());

                // cout << "point light input: " << numOfPointLights << endl;

                // inputFile >> numOfPointLights;
                for (int i = 0; i < numOfPointLights; i++)
                {
                    inputPointLight();
                }
            }
            else if (i == numOfObjects + 1)
            {
                numOfSpotLights = atoi(objectType.c_str());
                // cout << "spot light input: " << numOfSpotLights << endl;

                // inputFile >> numOfSpotLights;
                for (int i = 0; i < numOfSpotLights; i++)
                {
                    inputSpotLight();
                }
            }
        }
    }

    // Object *floorObj;;

    Object *floorObj = new Floor(1000, 20); // you can change these values
    floorObj->setColor(Color(1.0, 1.0, 1.0));
    // floorObj->setColor2(Color(0.0, 0.0, 0.0));
    floorObj->setCoEfficients(CoEfficients(0.3, 0.3, 0.3, 0.3));
    floorObj->setShine(10);

    // basePointer = (Object *)(&floorObj);
    allObjects.push_back(floorObj);

    // cout << "pushed floor" << endl;
}

Vector3D vectorScalarMultiply(Vector3D vec, double scalar)
{
    Vector3D product;

    product.x = scalar * vec.x;
    product.y = scalar * vec.y;
    product.z = scalar * vec.z;

    return product;
}

Vector3D vectorMultiply(Vector3D first, Vector3D second)
{

    Vector3D product;

    product.x = first.y * second.z - first.z * second.y;
    product.y = first.z * second.x - first.x * second.z;
    product.z = first.x * second.y - first.y * second.x;

    return product;
}

Vector3D vectorAddition(Vector3D first, Vector3D second, double scaling)
{
    Vector3D sum;

    sum.x = first.x + second.x * scaling;
    sum.y = first.y + second.y * scaling;
    sum.z = first.z + second.z * scaling;

    return sum;
}

Vector3D vectorRotation(Vector3D refVector, Vector3D rotorVector, double rotationAngle)
{

    Vector3D perpendicular = vectorMultiply(refVector, rotorVector);

    Vector3D cosPart, sinPart;

    cosPart = vectorScalarMultiply(rotorVector, cos(rotationAngle * pi / 180));
    sinPart = vectorScalarMultiply(perpendicular, sin(rotationAngle * pi / 180));

    Vector3D newVector = vectorAddition(cosPart, sinPart, 1.0);

    return newVector;
}

void Capture()
{

    bitmap_image bitImg(imageWidthPixel, imageHeightPixel);

    for (int i = 0; i < imageWidthPixel; i++)
    {
        for (int j = 0; j < imageHeightPixel; j++)
        {
            bitImg.set_pixel(i, j, 0, 0, 0);
        }
    }

    // initialize bitmap image and set background color
    // double planeDistance = (windowHeight / 2.0) / tan((viewAngle * pi) / (2.0 * 180));

    double planeDistance = (windowHeight) / (2.0 * tan((viewAngle * pi) / (2.0 * 180)));

    // topleft = eye + l * planeDistance - r * windowWidth / 2 + u * windowHeight / 2;

    Vector3D top_left = cameraPos.VectorAddition(looking.VectorScalarMultiply(planeDistance));

    top_left = top_left.VectorSubtract(Right.VectorScalarMultiply(windowWidth / 2.0));
    top_left = top_left.VectorAddition(up.VectorScalarMultiply(windowHeight / 2.0));

    double du = ((double)windowWidth * 1.0 / imageWidthPixel);
    double dv = ((double)windowHeight * 1.0 / imageHeightPixel);
    // Choose middle of the grid cell
    // topleft = topleft + r * (0.5 * du) - u * (0.5 * dv) int nearest;

    top_left = top_left.VectorSubtract(up.VectorScalarMultiply(0.5 * dv));
    top_left = top_left.VectorAddition(Right.VectorScalarMultiply(0.5 * du));

    // cout << "before capture for loop" << endl;

    for (int i = 0; i < imageWidthPixel; i++)
    {

        for (int j = 0; j < imageHeightPixel; j++)
        {
            // cout << "inner for loop" << endl;
            double min_t = INF, t;
            int closest = INF2;

            Vector3D currentPixel = top_left.VectorAddition(Right.VectorScalarMultiply(i * du));

            currentPixel = currentPixel.VectorSubtract(up.VectorScalarMultiply(j * dv));

            Ray eyeToObj(cameraPos, currentPixel.VectorSubtract(cameraPos));

            // cout << "objects for loop" << endl;
            for (int k = 0; k < allObjects.size(); k++)
            {
                Color tempColor;

                // cout << "before object intersection: " << endl;

                t = allObjects[k]->intersect(eyeToObj, tempColor, 0);

                // cout << "after object intersection" << endl;

                bool inside_range = (t < min_t && t > 0.0);
                if (inside_range)
                {
                    min_t = t;
                    closest = k;
                }
            }

            if (closest != INF2)
            {
                // cout << "before setting pixel" << endl;
                Color tempColor;
                int rVal, gVal, bVal;
                min_t = allObjects[closest]->intersect(eyeToObj, tempColor, 1);
                rVal = int(round(tempColor.r_value * 255.0));
                gVal = int(round(tempColor.g_value * 255.0));
                bVal = int(round(tempColor.b_value * 255.0));
                bitImg.set_pixel(i, j, rVal, gVal, bVal);
            }
        }
    }

    // cout << "before bitmap img saving" << endl;

    numOfImages++;
    char nameCh[10];
    string imageName = itoa(numOfImages, nameCh, 10);

    bitImg.save_image("G:/VARSITY/CSE 409 - COMPUTER GRAPHICS/LAB/OFFLINE_3/CODE/RAY_TRACING_FINAL/RAY_FINAL/images/image" + imageName + ".bmp");

    // bitImg.save_image("/images/image" + imageName + ".bmp");

    cout << "eye position: " << cameraPos.x << " " << cameraPos.y << " " << cameraPos.z << ": bitmap img captured" << endl;
}

void drawAllLights()
{
    // cout << "size of lights: " << allPointLights.size() << endl;
    for (int i = 0; i < allPointLights.size(); i++)
    {
        // cout << "inside lights for" << endl;
        allPointLights[i].draw();
        // cout << "lights drawn " << endl;
    }

    for (int i = 0; i < allSpotLights.size(); i++)
    {
        // cout << "inside lights for" << endl;
        allSpotLights[i].draw();
        // cout << "lights drawn " << endl;
    }

    // cout << "drawAllLights end" << endl;
}

void clearAllLights()
{
    std::vector<PointLight>().swap(allPointLights);
}

void drawAllObjects()
{

    for (int i = 0; i < allObjects.size(); i++)
    {
        allObjects[i]->draw();
        // cout << "object drawn " << endl;
    }
}

void clearAllObjects()
{

    for (int i = 0; i < allObjects.size(); i++)
    {
        delete allObjects[i];
    }

    std::vector<Object *>().swap(allObjects);
}

void display()
{

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glClearColor(0, 0, 0, 0); // color black
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    /********************
    / set-up camera here
    ********************/
    // load the correct matrix -- MODEL-VIEW matrix
    glMatrixMode(GL_MODELVIEW);

    // initialize the matrix
    glLoadIdentity();

    gluLookAt(cameraPos.x, cameraPos.y, cameraPos.z, cameraPos.x + looking.x, cameraPos.y + looking.y, cameraPos.z + looking.z, up.x, up.y, up.z);

    // again select MODEL-VIEW
    glMatrixMode(GL_MODELVIEW);

    /****************************
    / Add your objects from here
    ****************************/

    // cout << "before axes" << endl;

    drawAxes();

    // cout << "before lights" << endl;

    drawAllLights();

    // cout << "before objects" << endl;

    // if (myCounter == 1)
    // {
    //     cout << "after drawing light" << endl;
    // }

    drawAllObjects();
    myCounter++;

    // if (myCounter == 1)
    // {
    //     cout << "after drawing objects" << endl;
    // }

    glutSwapBuffers();
}

void animate()
{
    angle += 0.01;
    glutPostRedisplay();
}

void init()
{
    // codes for initialization
    viewAngle = 80.0;
    drawaxes = 1;
    cameraHeight = 150.0;
    cameraAngle = 1.0;

    // initializing global vars
    // cylHeight, sphereRadius, squareLen;

    cameraPos.x = 100.0;
    cameraPos.y = 100.0;
    cameraPos.z = 100.0;

    up.x = 0;
    up.y = 0;
    up.z = 1;

    Right.x = -1.0 / sqrt(2);
    Right.y = 1.0 / sqrt(2);
    Right.z = 0.0;

    looking.x = -1.0 / sqrt(2);
    looking.y = -1.0 / sqrt(2);
    looking.z = 0.0;

    // looking.x = -1.0 / sqrt(2);
    // looking.y = 0.0;
    // looking.z = -1.0 / sqrt(2);

    // clear the screen
    glClearColor(0, 0, 0, 0);

    /************************
    / set-up projection here
    ************************/
    // load the PROJECTION matrix
    glMatrixMode(GL_PROJECTION);

    // initialize the matrix
    glLoadIdentity();

    // give PERSPECTIVE parameters
    gluPerspective(viewAngle, 1, 1, 1000.0);
    // field of view in the Y (vertically)
    // aspect ratio that determines the field of view in the X direction (horizontally)
    // near distance
    // far distance
}

void keyboardListener(unsigned char key, int x, int y)
{

    double rotation = 2.0;
    switch (key)
    {

    case '1':
        // drawgrid=1-drawgrid;

        looking = vectorRotation(up, looking, rotation);
        Right = vectorMultiply(looking, up);

        break;

    case '2':
        looking = vectorRotation(up, looking, -rotation);
        Right = vectorMultiply(looking, up);

        break;

    case '3':
        looking = vectorRotation(Right, looking, rotation);
        up = vectorMultiply(Right, looking);

        break;

    case '4':
        looking = vectorRotation(Right, looking, -rotation);
        up = vectorMultiply(Right, looking);

        break;

    case '5':
        Right = vectorRotation(looking, Right, -rotation);
        up = vectorMultiply(Right, looking);

        break;

    case '6':
        Right = vectorRotation(looking, Right, rotation);
        up = vectorMultiply(Right, looking);

        break;
    case 'c':
        cout << "Capturing" << endl;
        Capture();
        break;

    default:
        break;
    }
}

void specialKeyListener(int key, int x, int y)
{

    Vector3D forward_move;
    double factor = 5.0;
    Vector3D negativeVector;

    switch (key)
    {
    case GLUT_KEY_DOWN: // down arrow key
        // cameraHeight -= 3.0;

        negativeVector = vectorScalarMultiply(looking, -1.0);
        cameraPos = vectorAddition(cameraPos, negativeVector, scaling);

        break;
    case GLUT_KEY_UP: // up arrow key
        // cameraHeight += 3.0;

        cameraPos = vectorAddition(cameraPos, looking, scaling);
        break;

    case GLUT_KEY_RIGHT:
        // cameraAngle += 0.03;

        cameraPos = vectorAddition(cameraPos, Right, scaling);
        break;
    case GLUT_KEY_LEFT:

        // cameraAngle -= 0.03;

        negativeVector = vectorScalarMultiply(Right, -1.0);
        cameraPos = vectorAddition(cameraPos, negativeVector, scaling);

        break;

    case GLUT_KEY_PAGE_UP:

        cameraPos = vectorAddition(cameraPos, up, scaling);
        break;
    case GLUT_KEY_PAGE_DOWN:

        negativeVector = vectorScalarMultiply(up, -1.0);
        cameraPos = vectorAddition(cameraPos, negativeVector, scaling);

        break;

    case GLUT_KEY_INSERT:
        break;
    default:
        break;
    }
}

void mouseListener(int button, int state, int x, int y)
{ // x, y is the x-y of the screen (2D)
    switch (button)
    {
    case GLUT_LEFT_BUTTON:
        if (state == GLUT_DOWN)
        { // 2 times?? in ONE click? -- solution is checking DOWN or UP
            drawaxes = 1 - drawaxes;
        }
        break;

    case GLUT_RIGHT_BUTTON:
        //........
        break;

    case GLUT_MIDDLE_BUTTON:
        //........
        break;

    default:
        break;
    }
}

int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitWindowSize(windowWidth, windowHeight);
    glutInitWindowPosition(0, 0);
    glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGB); // Depth, Double buffer, RGB color

    glutCreateWindow("Ray Tracing Offline");

    init();

    glEnable(GL_DEPTH_TEST); // enable Depth Testing

    glutDisplayFunc(display); // display callback function
    glutIdleFunc(animate);    // what you want to do in the idle time (when no drawing is occuring)

    glutKeyboardFunc(keyboardListener);
    glutSpecialFunc(specialKeyListener);
    glutMouseFunc(mouseListener);

    cout << "before load data" << endl;

    loadData();

    cout << "load data complete" << endl;

    glutMainLoop();

    return 0;
}
