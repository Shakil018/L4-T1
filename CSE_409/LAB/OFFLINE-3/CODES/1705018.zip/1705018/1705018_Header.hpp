
#include <iostream>
#include <fstream>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include <windows.h>
#include <GL/glut.h>
#include <limits>

using namespace std;

#define pi (2 * acos(0.0))
#define INF numeric_limits<double>::infinity()
#define INF2 10000000

double delta = 0.0000001;

int recursionDepth = 0;

class Color
{
public:
    double r_value, g_value, b_value;

    Color()
    {
        this->r_value = 0;
        this->g_value = 0;
        this->b_value = 0;
    }

    Color(double redVal, double greenVal, double blueVal)
    {
        this->r_value = redVal;
        this->g_value = greenVal;
        this->b_value = blueVal;
    }
};

class Vector3D
{
public:
    double x, y, z;

    Vector3D()
    {
        this->x = 0;
        this->y = 0;
        this->z = 0;
    }

    Vector3D(double x, double y, double z)
    {
        this->x = x;
        this->y = y;
        this->z = z;
    }

    void Normalize()
    {
        double resultant = sqrt(x * x + y * y + z * z);

        this->x /= resultant;
        this->y /= resultant;
        this->z /= resultant;
    }

    double VectorDotProduct(Vector3D b)
    {
        double result;
        result = this->x * b.x + this->y * b.y + this->z * b.z;

        return result;
    }

    Vector3D vectorCrossProduct(Vector3D b)
    {
        Vector3D result;
        Vector3D a(this->x, this->y, this->z);

        result.x = a.y * b.z - a.z * b.y;
        result.y = a.z * b.x - a.x * b.z;
        result.z = a.x * b.y - a.y * b.x;

        return result;
    }

    Vector3D VectorScalarMultiply(double scalar)
    {
        Vector3D temp(this->x, this->y, this->z);

        temp.x *= scalar;
        temp.y *= scalar;
        temp.z *= scalar;
        return temp;
    }

    Vector3D VectorSubtract(Vector3D b)
    {
        Vector3D temp(this->x, this->y, this->z);

        temp.x -= b.x;
        temp.y -= b.y;
        temp.z -= b.z;

        return temp;
    }

    Vector3D VectorAddition(Vector3D b)
    {
        Vector3D temp(this->x, this->y, this->z);

        temp.x += b.x;
        temp.y += b.y;
        temp.z += b.z;

        return temp;
    }

    double CalcDistance(Vector3D b)
    {
        double result;
        result = sqrt(pow(this->x - b.x, 2) + pow(this->y - b.y, 2) + pow(this->z - b.z, 2));
        return result;
    }

    double DeterminantValue(Vector3D vec1, Vector3D vec2, Vector3D vec3)
    {
        double result = vec1.x * (vec2.y * vec3.z - vec2.z * vec3.y);

        result += vec1.y * (vec2.z * vec3.x - vec2.x * vec3.z);
        result += vec1.z * (vec2.x * vec3.y - vec2.y * vec3.x);

        return result;
    }
};

Vector3D cameraPos;

class CoEfficients
{
public:
    double ambient;
    double diffuse;
    double specular;
    double reflection;

    CoEfficients()
    {
        this->ambient = 0;
        this->diffuse = 0;
        this->specular = 0;
        this->reflection = 0;
    }

    CoEfficients(double ambient, double diffuse, double specular, double reflection)
    {
        this->ambient = ambient;
        this->diffuse = diffuse;
        this->specular = specular;
        this->reflection = reflection;
    }
};

class Ray
{
public:
    Vector3D origin_vec;
    Vector3D direction_vec; // normalize for easier calculations
    // write appropriate constructor

    Ray()
    {
    }

    Ray(Vector3D origin_vec, Vector3D direction_vec)
    {
        direction_vec.Normalize();
        this->origin_vec = origin_vec;
        this->direction_vec = direction_vec;
    }
};

class PointLight
{
public:
    Vector3D light_position;
    Color color;
    int segments, stacks;

    PointLight()
    {
        Vector3D tempVect(0, 0, 0);
        Color tempColor(0, 0, 0);
        this->light_position = tempVect;
        this->color = tempColor;
        this->segments = 0;
        this->stacks = 0;
    }

    PointLight(Vector3D light_position, Color color, int segments = 10, int stacks = 5)
    {
        this->light_position = light_position;
        this->color = color;
        this->segments = segments;
        this->stacks = stacks;
    }

    void draw()
    {
        glPointSize(5.0);
        glColor3f(this->color.r_value, this->color.g_value, this->color.b_value);

        glBegin(GL_POINTS);
        glVertex3f(this->light_position.x, this->light_position.y, this->light_position.z);
        glEnd();
    }
};

class SpotLight
{
public:
    PointLight point_light;
    Vector3D light_direction;
    double cutoff_angle;

    double coneRadius = 1.0;
    int segments, stacks;

    SpotLight()
    {
        Vector3D tempVect(0, 0, 0);
        Color tempColor(0, 0, 0);
        this->point_light = PointLight(tempVect, tempColor, 0, 0);
        this->light_direction = tempVect;
        this->cutoff_angle = 0;
        this->segments = 0;
        this->stacks = 0;
    }

    SpotLight(PointLight point_light, Vector3D light_direction, double cutoff_angle, int segments = 10, int stacks = 5)
    {
        this->point_light = point_light;
        this->light_direction = light_direction;
        this->cutoff_angle = cutoff_angle;
        this->segments = segments;
        this->stacks = stacks;
    }

    void draw()
    {

        glPointSize(5.0);
        glColor3f(point_light.color.r_value, point_light.color.g_value, point_light.color.b_value);

        glBegin(GL_POINTS);
        glVertex3f(point_light.light_position.x, point_light.light_position.y, point_light.light_position.z);
        glEnd();
    }
};

class Object
{
public:
    Vector3D reference_point; // should have x, y, z
    double height, width, length;
    Color color;
    CoEfficients coefficients; // ambient, diffuse, specular, reflection coefficients
    int shine;                 // exponent term of specular component

    Object()
    {
        this->height = 0;
        this->width = 0;
        this->length = 0;
    }
    Object(double height, double width, double length)
    {
        this->height = height;
        this->width = width;
        this->length = length;
    }

    virtual void draw() = 0;

    virtual double intersect(Ray r, Color &color, int level) = 0;

    void setColor(Color color)
    {
        this->color = color;
    }
    void setShine(int shine)
    {
        this->shine = shine;
    }
    void setCoEfficients(CoEfficients coefficients)
    {
        this->coefficients = coefficients;
    }

    Color DiffuseComponent(Ray L, Vector3D planeNormal, PointLight light, Vector3D interPoint, Color color, Color interColor)
    {

        Color tempColor = color;

        Vector3D inverted_ray_vec = L.direction_vec.VectorScalarMultiply(-1.0);
        double dotProduct = planeNormal.VectorDotProduct(inverted_ray_vec);

        double max_term = max(dotProduct, 0.0);
        tempColor.r_value += light.color.r_value * (interColor.r_value * coefficients.diffuse * max_term);
        tempColor.g_value += light.color.g_value * (interColor.g_value * coefficients.diffuse * max_term);
        tempColor.b_value += light.color.b_value * (interColor.b_value * coefficients.diffuse * max_term);

        return tempColor;
    }

    Color SpecularComponent(Ray V, Ray L, Vector3D planeNormal, PointLight light, Color color, Color interColor)
    {

        Color tempColor = color;

        double LdotN = L.direction_vec.VectorDotProduct(planeNormal);
        Vector3D reflection_direction = L.direction_vec;
        reflection_direction = reflection_direction.VectorSubtract(planeNormal.VectorScalarMultiply(2.0 * LdotN));

        Vector3D inverted_view = V.direction_vec.VectorScalarMultiply(-1.0);
        double RdotV = reflection_direction.VectorDotProduct(inverted_view);

        double exp_term = pow(max(RdotV, 0.0), this->shine);
        tempColor.r_value += light.color.r_value * (interColor.r_value * coefficients.specular * exp_term);
        tempColor.g_value += light.color.g_value * (interColor.g_value * coefficients.specular * exp_term);
        tempColor.b_value += light.color.b_value * (interColor.b_value * coefficients.specular * exp_term);

        return tempColor;
    }

    Color DiffuseComponent(Ray L, Vector3D planeNormal, SpotLight light, Vector3D interPoint, Color color, Color interColor)
    {

        Color tempColor = color;

        Vector3D inverted_ray_vec = L.direction_vec.VectorScalarMultiply(-1.0);
        double dotProduct = planeNormal.VectorDotProduct(inverted_ray_vec);

        double max_term = max(dotProduct, 0.0);
        tempColor.r_value += light.point_light.color.r_value * (interColor.r_value * coefficients.diffuse * max_term);
        tempColor.g_value += light.point_light.color.g_value * (interColor.g_value * coefficients.diffuse * max_term);
        tempColor.b_value += light.point_light.color.b_value * (interColor.b_value * coefficients.diffuse * max_term);

        return tempColor;
    }

    Color SpecularComponent(Ray V, Ray L, Vector3D planeNormal, SpotLight light, Color color, Color interColor)
    {

        Color tempColor = color;

        double LdotN = L.direction_vec.VectorDotProduct(planeNormal);
        Vector3D reflection_direction = L.direction_vec;
        reflection_direction = reflection_direction.VectorSubtract(planeNormal.VectorScalarMultiply(2.0 * LdotN));

        Vector3D inverted_view = V.direction_vec.VectorScalarMultiply(-1.0);
        double RdotV = reflection_direction.VectorDotProduct(inverted_view);

        double exp_term = pow(max(RdotV, 0.0), this->shine);
        tempColor.r_value += light.point_light.color.r_value * (interColor.r_value * coefficients.specular * exp_term);
        tempColor.g_value += light.point_light.color.g_value * (interColor.g_value * coefficients.specular * exp_term);
        tempColor.b_value += light.point_light.color.b_value * (interColor.b_value * coefficients.specular * exp_term);

        return tempColor;
    }

    Color ReflectionComponent(Color currentColor, Color refColor)
    {
        Color tempColor = currentColor;
        tempColor.r_value += refColor.r_value * coefficients.reflection;
        tempColor.g_value += refColor.g_value * coefficients.reflection;
        tempColor.b_value += refColor.b_value * coefficients.reflection;
        return tempColor;
    }

    Color AmbientComponent(Color &tempColor, Color interColor)
    {
        // Color tempColor;
        tempColor.r_value = interColor.r_value * coefficients.ambient;
        tempColor.g_value = interColor.g_value * coefficients.ambient;
        tempColor.b_value = interColor.b_value * coefficients.ambient;

        // return tempColor;
    }
};

vector<Object *> allObjects;
vector<PointLight> allPointLights;
vector<SpotLight> allSpotLights;

double ComputeLightShadow(Object *obj, Ray r, Color &myColor, int level, Vector3D &intersection_point, Vector3D &intersection_normal, Color &intersection_color, double min_t)
{
    // myColor = obj->AmbientComponent(intersection_color);

    obj->AmbientComponent(myColor, intersection_color);

    for (int i = 0; i < allPointLights.size(); i++)
    {
        Vector3D direction = intersection_point.VectorSubtract(allPointLights[i].light_position);
        Ray eyeToObject = Ray(allPointLights[i].light_position, direction);

        double min_t2 = INF, t;

        for (int k = 0; k < allObjects.size(); k++)
        {
            Color tempColor;
            t = allObjects[k]->intersect(eyeToObject, tempColor, 0);

            if (t < min_t2 && t > 0.0)
            {
                min_t2 = t;
            }
        }

        Vector3D shadow_intersection_point = eyeToObject.origin_vec.VectorAddition(eyeToObject.direction_vec.VectorScalarMultiply(min_t2));

        double originToIntersection = intersection_point.CalcDistance(eyeToObject.origin_vec) - delta;
        double originToShadow = shadow_intersection_point.CalcDistance(eyeToObject.origin_vec);

        if (originToShadow <= originToIntersection)
        {
            continue;
        }

        myColor = obj->DiffuseComponent(eyeToObject, intersection_normal, allPointLights[i], intersection_point, myColor, intersection_color);
        myColor = obj->SpecularComponent(r, eyeToObject, intersection_normal, allPointLights[i], myColor, intersection_color);
    }

    for (int i = 0; i < allSpotLights.size(); i++)
    {
        Vector3D direction = intersection_point.VectorSubtract(allSpotLights[i].point_light.light_position);
        direction.Normalize();
        Vector3D temp = allSpotLights[i].light_direction;
        temp.Normalize();
        double dotProduct = temp.VectorDotProduct(direction);

        double value_square = temp.VectorDotProduct(temp);
        double direction_square = direction.VectorDotProduct(direction);

        double cos_theta = dotProduct * 1.0 / (sqrt(value_square) * sqrt(direction_square));
        double theta = acos(cos_theta);

        if ((theta * 180.0) / pi > allSpotLights[i].cutoff_angle)
        {
            continue;
        }

        Vector3D direction2 = intersection_point.VectorSubtract(allSpotLights[i].point_light.light_position);
        direction2.Normalize();
        Ray eyeToObject = Ray(allSpotLights[i].point_light.light_position, direction2);

        double min_t2 = INF, t;

        for (int k = 0; k < allObjects.size(); k++)
        {
            Color tempColor;
            t = allObjects[k]->intersect(eyeToObject, tempColor, 0);

            if (t < min_t2 && t > 0.0)
            {
                min_t2 = t;
            }
        }

        Vector3D shadow_intersection_point = eyeToObject.origin_vec.VectorAddition(eyeToObject.direction_vec.VectorScalarMultiply(min_t2));

        double originToIntersection = intersection_point.CalcDistance(eyeToObject.origin_vec) - delta;
        double originToShadow = shadow_intersection_point.CalcDistance(eyeToObject.origin_vec);

        if (originToShadow <= originToIntersection)
        {
            continue;
        }

        myColor = obj->DiffuseComponent(eyeToObject, intersection_normal, allSpotLights[i], intersection_point, myColor, intersection_color);
        myColor = obj->SpecularComponent(r, eyeToObject, intersection_normal, allSpotLights[i], myColor, intersection_color);
    }
}

double ComputeColor(Object *obj, Ray r, Color &myColor, int level, Vector3D intersection_point, Vector3D intersection_normal)
{
    double dotProduct = r.direction_vec.VectorDotProduct(intersection_normal);
    Vector3D reflection_dir = r.direction_vec.VectorSubtract(intersection_normal.VectorScalarMultiply(2.0 * dotProduct));
    reflection_dir.Normalize();

    Ray reflectionRay(intersection_point.VectorAddition(reflection_dir), reflection_dir);

    double t, min_t2 = INF;
    int closest = INF2;

    for (int i = 0; i < allObjects.size(); i++)
    {
        Color tempColor;
        t = allObjects[i]->intersect(reflectionRay, tempColor, 0);

        if (t < min_t2 && t > 0.0)
        {
            min_t2 = t;
            closest = i;
        }
    }

    Color reflection_color;

    if (closest != INF2)
    {
        min_t2 = allObjects[closest]->intersect(reflectionRay, reflection_color, level + 1);
    }

    myColor = obj->ReflectionComponent(myColor, reflection_color);

    myColor.r_value = min(myColor.r_value, 1.0);
    myColor.r_value = max(myColor.r_value, 0.0);

    myColor.g_value = min(myColor.g_value, 1.0);
    myColor.g_value = max(myColor.g_value, 0.0);

    myColor.b_value = min(myColor.b_value, 1.0);
    myColor.b_value = max(myColor.b_value, 0.0);
}

class Sphere : public Object
{
public:
    Vector3D sphereCenter;
    double radius;
    int slices, stacks;

    Sphere()
    {
        Vector3D temp_ref(0, 0, 0);
        this->sphereCenter = temp_ref;
        this->radius = 0;
        this->slices = 0;
        this->stacks = 0;
    }

    Sphere(Vector3D sphereCenter, double radius, int stacks = 30, int slices = 60)
    {
        this->sphereCenter = sphereCenter;
        this->radius = radius;
        this->slices = slices;
        this->stacks = stacks;
    }

    void draw()
    {
        // cout << "inside sphere draw" << endl;
        struct Vector3D points[100][100];
        int i, j;
        double h, r;
        // generate points
        for (i = 0; i <= stacks; i++)
        {
            h = radius * sin(((double)i / (double)stacks) * (pi / 2));
            r = radius * cos(((double)i / (double)stacks) * (pi / 2));
            for (j = 0; j <= slices; j++)
            {
                points[i][j].x = r * cos(((double)j / (double)slices) * 2 * pi);
                points[i][j].y = r * sin(((double)j / (double)slices) * 2 * pi);
                points[i][j].z = h;
            }
        }

        // cout << "after generating points" << endl;

        glColor3f(color.r_value, color.g_value, color.b_value);

        // draw quads using generated points
        for (i = 0; i < stacks; i++)
        {
            for (j = 0; j < slices; j++)
            {
                glBegin(GL_QUADS);
                {
                    // upper hemisphere
                    glVertex3f(sphereCenter.x + points[i][j].x, sphereCenter.y + points[i][j].y, sphereCenter.z + points[i][j].z);
                    glVertex3f(sphereCenter.x + points[i][j + 1].x, sphereCenter.y + points[i][j + 1].y, sphereCenter.z + points[i][j + 1].z);
                    glVertex3f(sphereCenter.x + points[i + 1][j + 1].x, sphereCenter.y + points[i + 1][j + 1].y, sphereCenter.z + points[i + 1][j + 1].z);
                    glVertex3f(sphereCenter.x + points[i + 1][j].x, sphereCenter.y + points[i + 1][j].y, sphereCenter.z + points[i + 1][j].z);
                    // lower hemisphere
                    glVertex3f(sphereCenter.x + points[i][j].x, sphereCenter.y + points[i][j].y, sphereCenter.z - points[i][j].z);
                    glVertex3f(sphereCenter.x + points[i][j + 1].x, sphereCenter.y + points[i][j + 1].y, sphereCenter.z - points[i][j + 1].z);
                    glVertex3f(sphereCenter.x + points[i + 1][j + 1].x, sphereCenter.y + points[i + 1][j + 1].y, sphereCenter.z - points[i + 1][j + 1].z);
                    glVertex3f(sphereCenter.x + points[i + 1][j].x, sphereCenter.y + points[i + 1][j].y, sphereCenter.z - points[i + 1][j].z);
                }
                glEnd();
            }
        }
    }

    double intersect(Ray r, Color &myColor, int level)
    {
        double squaredTerm, linearTerm, constantTerm, discriminant, min_t, max_t;

        squaredTerm = r.direction_vec.VectorDotProduct(r.direction_vec);
        linearTerm = 2 * r.direction_vec.VectorDotProduct(r.origin_vec.VectorSubtract(this->sphereCenter));

        Vector3D temp = r.origin_vec.VectorSubtract(this->sphereCenter);
        constantTerm = temp.VectorDotProduct(temp) - pow(this->radius, 2);

        double disc = linearTerm * linearTerm - 4.0 * squaredTerm * constantTerm;

        if (disc > 0.0)
        {
            max_t = (-linearTerm + sqrt(disc)) / (2.0 * squaredTerm);
            min_t = (-linearTerm - sqrt(disc)) / (2.0 * squaredTerm);
            if (min_t < 0.0)
            {
                min_t = max_t;
            }
        }
        else if (abs(disc) < delta)
        {
            min_t = -linearTerm / (2.0 * squaredTerm);
        }
        else
        {
            min_t = INF;
        }

        if (level == 0)
            return min_t;

        Color intersection_color = this->color;
        Vector3D intersection_point = r.origin_vec.VectorAddition(r.direction_vec.VectorScalarMultiply(min_t));

        Vector3D intersection_normal = intersection_point.VectorSubtract(this->sphereCenter);
        intersection_normal.Normalize();

        double distance = this->sphereCenter.CalcDistance(cameraPos);

        if (this->radius >= distance)
        {
            // inside sphere:
            intersection_normal = intersection_normal.VectorScalarMultiply(-1.0);
        }

        ComputeLightShadow(this, r, myColor, level, intersection_point, intersection_normal, intersection_color, min_t);

        if (level >= recursionDepth)
        {
            return min_t;
        }

        ComputeColor(this, r, myColor, level, intersection_point, intersection_normal);

        return min_t;
    }
};

class Triangle : public Object
{
public:
    Vector3D edge1, edge2, edge3;

    Triangle()
    {
        this->edge1 = Vector3D(0.0, 0.0, 0.0);
        this->edge2 = Vector3D(0.0, 0.0, 0.0);
        this->edge3 = Vector3D(0.0, 0.0, 0.0);
    }

    Triangle(Vector3D edge1, Vector3D edge2, Vector3D edge3)
    {
        this->edge1 = edge1;
        this->edge2 = edge2;
        this->edge3 = edge3;
    }

    void draw()
    {
        // cout << "inside triangle draw" << endl;

        glColor3f(this->color.r_value, this->color.g_value, this->color.b_value);

        glBegin(GL_TRIANGLES);
        {
            glVertex3f(edge1.x, edge1.y, edge1.z);
            glVertex3f(edge2.x, edge2.y, edge2.z);
            glVertex3f(edge3.x, edge3.y, edge3.z);
        }
        glEnd();

        // cout << "inside sphere draw end" << endl;
    }

    double intersect(Ray r, Color &myColor, int level)
    {
        Vector3D temp1(edge1.x - edge2.x, edge1.x - edge3.x, r.direction_vec.x);
        Vector3D temp2(edge1.y - edge2.y, edge1.y - edge3.y, r.direction_vec.y);
        Vector3D temp3(edge1.z - edge2.z, edge1.z - edge3.z, r.direction_vec.z);

        double A = temp1.DeterminantValue(temp1, temp2, temp3);

        temp1.x = edge1.x - r.origin_vec.x;
        temp1.y = edge1.x - edge3.x;
        temp1.z = r.direction_vec.x;

        temp2.x = edge1.y - r.origin_vec.y;
        temp2.y = edge1.y - edge3.y;
        temp2.z = r.direction_vec.y;

        temp3.x = edge1.z - r.origin_vec.z;
        temp3.y = edge1.z - edge3.z;
        temp3.z = r.direction_vec.z;

        double Beta = (temp1.DeterminantValue(temp1, temp2, temp3));

        temp1.x = edge1.x - edge2.x;
        temp1.y = edge1.x - r.origin_vec.x;
        temp1.z = r.direction_vec.x;

        temp2.x = edge1.y - edge2.y;
        temp2.y = edge1.y - r.origin_vec.y;
        temp2.z = r.direction_vec.y;

        temp3.x = edge1.z - edge2.z;
        temp3.y = edge1.z - r.origin_vec.z;
        temp3.z = r.direction_vec.z;

        double Gamma = (temp1.DeterminantValue(temp1, temp2, temp3));

        temp1.x = edge1.x - edge2.x;
        temp1.y = edge1.x - edge3.x;
        temp1.z = edge1.x - r.origin_vec.x;

        temp2.x = edge1.y - edge2.y;
        temp2.y = edge1.y - edge3.y;
        temp2.z = edge1.y - r.origin_vec.y;

        temp3.x = edge1.z - edge2.z;
        temp3.y = edge1.z - edge3.z;
        temp3.z = edge1.z - r.origin_vec.z;

        double t = (temp1.DeterminantValue(temp1, temp2, temp3));

        double min_t;

        if (A == 0.0)
        {
            min_t = INF;
        }
        else
        {
            Beta /= A;
            Gamma /= A;
            t /= A;

            if (Beta > 0.0 && Gamma > 0.0 && Beta + Gamma < 1.0)
            {
                min_t = t;
            }
            else
            {
                min_t = INF;
            }
        }

        if (level == 0)
        {
            return min_t;
        }

        Vector3D parameter_part = r.direction_vec.VectorScalarMultiply(min_t);
        Vector3D intersection_point = r.origin_vec.VectorAddition(parameter_part);

        Color intersection_color = this->color;

        Vector3D intersection_normal(edge2.x - edge1.x, edge2.y - edge1.y, edge2.z - edge1.z);
        intersection_normal.vectorCrossProduct(Vector3D(edge3.x - edge1.x, edge3.y - edge1.y, edge3.z - edge1.z));
        intersection_normal.Normalize();

        double dotProduct = intersection_normal.VectorDotProduct(r.direction_vec.VectorScalarMultiply(-1.0));

        if (dotProduct <= 0.0)
        {
            intersection_normal = intersection_normal.VectorScalarMultiply(-1.0);
        }

        ComputeLightShadow(this, r, myColor, level, intersection_point, intersection_normal, intersection_color, min_t);

        if (level >= recursionDepth)
        {
            return min_t;
        }

        ComputeColor(this, r, myColor, level, intersection_point, intersection_normal);

        return min_t;
    }
};

class Floor : public Object
{
public:
    double floorWidth, tileWidth;
    Color color2;

    Floor()
    {
        this->floorWidth = 0.0;
        this->tileWidth = 0.0;
    }

    Floor(double floorWidth, double tileWidth)
    {
        Vector3D tempVect = Vector3D(-floorWidth / 2, -floorWidth / 2, 0);
        this->reference_point = tempVect;
        this->floorWidth = floorWidth;
        this->tileWidth = tileWidth;
        this->color2 = Color(0.0, 0.0, 0.0);
    }

    void setColor2(Color color2)
    {
        this->color2 = color2;
    }
    void draw()
    {
        // cout << "inside floor draw" << endl;
        int tilesCount = (int)(ceil(floorWidth / tileWidth));
        Color selected_color;

        bool first = true;

        for (int i = 0; i < tilesCount; i++)
        {
            for (int j = 0; j < tilesCount; j++)
            {
                if ((i + j) % 2 == 0)
                {
                    // selected_color = color;
                    selected_color = Color(0.0, 0.0, 0.0);
                    // cout << "black color" << endl;
                }
                else
                {
                    // selected_color = color2;
                    selected_color = Color(1.0, 1.0, 1.0);
                    // cout << "white color" << endl;
                }

                // if (first)
                // {
                //     selected_color = color2;
                //     first = false;
                // }
                // else
                // {
                //     selected_color = color;
                //     first = true;
                // }

                glColor3f(selected_color.r_value, selected_color.g_value, selected_color.b_value);

                glBegin(GL_QUADS);
                {
                    glVertex3f(reference_point.x + tileWidth * j, reference_point.y + tileWidth * i, reference_point.z);
                    glVertex3f(reference_point.x + tileWidth * (j + 1), reference_point.y + tileWidth * i, reference_point.z);
                    glVertex3f(reference_point.x + tileWidth * (j + 1), reference_point.y + tileWidth * (i + 1), reference_point.z);
                    glVertex3f(reference_point.x + tileWidth * j, reference_point.y + tileWidth * (i + 1), reference_point.z);
                }
                glEnd();
            }
        }
    }

    double intersect(Ray r, Color &myColor, int level)
    {
        // cout << "inside floor intersect" << endl;
        Vector3D planeNormal(0.0, 0.0, 1.0);

        double dotProduct = planeNormal.VectorDotProduct(cameraPos);

        if (dotProduct <= 0.0)
        {
            planeNormal = planeNormal.VectorScalarMultiply(-1.0);
        }

        double min_t = INF;
        dotProduct = planeNormal.VectorDotProduct(r.direction_vec);

        if (dotProduct != 0.0)
        {
            min_t = planeNormal.VectorDotProduct(r.origin_vec);
            min_t = -min_t / dotProduct;
        }

        Vector3D parameter_part = r.direction_vec.VectorScalarMultiply(min_t);
        Vector3D intersection_point = r.origin_vec.VectorAddition(parameter_part);

        if (min_t < INF && min_t > 0.0)
        {

            bool x_invalid_condition = (intersection_point.x < reference_point.x || intersection_point.x > reference_point.x + floorWidth);
            bool y_invalid_condition = (intersection_point.y < reference_point.y || intersection_point.y > reference_point.y + floorWidth);

            if (x_invalid_condition || y_invalid_condition)
            {
                min_t = INF;
            }
        }

        if (level == 0)
        {
            return min_t;
        }

        Vector3D planeVector = intersection_point.VectorSubtract(reference_point);

        int intersectionCol = (int)(floor(planeVector.x) / tileWidth);
        int intersectionRow = (int)(floor(planeVector.y) / tileWidth);
        int tilesCount = (int)(ceil(floorWidth / tileWidth));

        Color intersection_color;

        if ((intersectionRow + intersectionCol) % 2 == 0)
        {
            intersection_color = color;
        }
        else
        {
            intersection_color = color2;
        }

        ComputeLightShadow(this, r, myColor, level, intersection_point, planeNormal, intersection_color, min_t);

        if (level >= recursionDepth)
        {
            return min_t;
        }

        ComputeColor(this, r, myColor, level, intersection_point, planeNormal);

        return min_t;
    }
};

class QuadricSurfaceCoefficients
{
public:
    double A, B, C, D, E, F, G, H, I, J;

    QuadricSurfaceCoefficients()
    {
        this->A = 0.0;
        this->B = 0.0;
        this->C = 0.0;
        this->D = 0.0;
        this->E = 0.0;
        this->F = 0.0;
        this->G = 0.0;
        this->H = 0.0;
        this->I = 0.0;
        this->J = 0.0;
    }

    QuadricSurfaceCoefficients(double A, double B, double C, double D, double E, double F, double G, double H, double I, double J)
    {
        this->A = A;
        this->B = B;
        this->C = C;
        this->D = D;
        this->E = E;
        this->F = F;
        this->G = G;
        this->H = H;
        this->I = I;
        this->J = J;
    }

    void print(ofstream &outFile)
    {
        outFile << A << ", " << B << ", " << C << ", " << D << ", " << E << ", " << F << ", " << G << ", " << H << ", " << I << ", " << J << endl;
    }
};

class QuadricSurface : public Object
{
public:
    Vector3D reference_point;
    QuadricSurfaceCoefficients coefficients;

    double length, width, height;

    QuadricSurface()
    {
        this->length = 0.0;
        this->width = 0.0;
        this->height = 0.0;
    }

    QuadricSurface(double length, double width, double height, QuadricSurfaceCoefficients coefficients, Vector3D reference_point)
    {
        this->length = length;
        this->width = width;
        this->height = height;
        this->coefficients = coefficients;
        this->reference_point = reference_point;
    }

    void draw() {}

    void calcCoefficients(Vector3D origin, Vector3D direction, double &a, double &b, double &c)
    {
        double ox = origin.x;
        double oy = origin.y;
        double oz = origin.z;
        double dx = direction.x;
        double dy = direction.y;
        double dz = direction.z;

        double A = coefficients.A;
        double B = coefficients.B;
        double C = coefficients.C;
        double D = coefficients.D;
        double E = coefficients.E;
        double F = coefficients.F;
        double G = coefficients.G;
        double H = coefficients.H;
        double I = coefficients.I;
        double J = coefficients.J;

        a = A * pow(dx, 2) + B * pow(dy, 2) + C * pow(dz, 2) + D * dx * dy + E * dy * dz + F * dx * dz;
        b = 2 * A * ox * dx + 2 * B * oy * dy + 2 * C * oz * dz + D * (ox * dy + dx * oy) + E * (oy * dz + dy * oz) + F * (ox * dz + dx * oz) + G * dx + H * dy + I * dz;
        c = A * pow(ox, 2) + B * pow(oy, 2) + C * pow(oz, 2) + D * ox * oy + E * oy * oz + F * ox * oz + G * ox + H * oy + I * oz + J;

        // a = A * pow(dx, 2) + B * pow(dy, 2) + C * pow(dz, 2) + D * dx * dy + E * dx * dz + F * dy * dz;
        // b = 2 * A * ox * dx + 2 * B * oy * dy + 2 * C * oz * dz + D * (ox * dy + dx * oy) + E * (ox * dz + dx * oz) + F * (oy * dz + dy * oz) + G * dx + H * dy + I * dz;
        // c = A * pow(ox, 2) + B * pow(oy, 2) + C * pow(oz, 2) + D * ox * oy + E * ox * oz + F * oy * oz + G * ox + H * oy + I * oz + J;
    }

    Vector3D calcNormal(Vector3D intersection_point)
    {

        double A = coefficients.A;
        double B = coefficients.B;
        double C = coefficients.C;
        double D = coefficients.D;
        double E = coefficients.E;
        double F = coefficients.F;
        double G = coefficients.G;
        double H = coefficients.H;
        double I = coefficients.I;
        double J = coefficients.J;

        double differentiateX = 2 * A * intersection_point.x + D * intersection_point.y + F * intersection_point.z + G;
        double differentiateY = 2 * B * intersection_point.y + D * intersection_point.x + E * intersection_point.z + H;
        double differentiateZ = 2 * C * intersection_point.z + E * intersection_point.y + F * intersection_point.x + I;

        // double differentiateX = 2 * A * intersection_point.x + D * intersection_point.y + E * intersection_point.z + G;
        // double differentiateY = 2 * B * intersection_point.y + D * intersection_point.x + F * intersection_point.z + H;
        // double differentiateZ = 2 * C * intersection_point.z + E * intersection_point.x + F * intersection_point.y + I;

        Vector3D normalVect = Vector3D(differentiateX, differentiateY, differentiateZ);
        normalVect.Normalize();

        return normalVect;
    }

    double intersect(Ray r, Color &myColor, int level)
    {
        double squareTerm, linearTerm, constantTerm;

        calcCoefficients(r.origin_vec, r.direction_vec, squareTerm, linearTerm, constantTerm);

        double max_t = INF, min_t = INF;

        if (squareTerm == 0.0)
        {
            if (linearTerm == 0.0)
            {
                min_t = INF;
            }
            else
            {
                min_t = -constantTerm / linearTerm;
            }
        }
        else
        {
            double disc = pow(linearTerm, 2) - 4.0 * squareTerm * constantTerm;

            if (disc > 0.0)
            {
                max_t = (-linearTerm + sqrt(disc)) / (2 * squareTerm);
                min_t = (-linearTerm - sqrt(disc)) / (2 * squareTerm);
            }
            else if (disc == 0.0)
            {
                min_t = -linearTerm / (2.0 * squareTerm);
                max_t = INF;
            }
        }

        if (min_t < INF && max_t < INF)
        {
            if (min_t > 0.0)
            {
                Vector3D intersection_point = r.origin_vec.VectorAddition(r.direction_vec.VectorScalarMultiply(min_t));

                double x_invalid_condition = (length != 0) && (intersection_point.x < reference_point.x || intersection_point.x > reference_point.x + length);
                double y_invalid_condition = (width != 0) && (intersection_point.y < reference_point.y || intersection_point.y > reference_point.y + width);
                double z_invalid_condition = (height != 0) && (intersection_point.z < reference_point.z || intersection_point.z > reference_point.z + height);

                if (x_invalid_condition || y_invalid_condition || z_invalid_condition)
                {
                    min_t = INF;
                }
            }
            if (max_t > 0.0)
            {
                Vector3D intersection_point = r.origin_vec.VectorAddition(r.direction_vec.VectorScalarMultiply(max_t));

                double x_invalid_condition = (length != 0) && (intersection_point.x < reference_point.x || intersection_point.x > reference_point.x + length);
                double y_invalid_condition = (width != 0) && (intersection_point.y < reference_point.y || intersection_point.y > reference_point.y + width);
                double z_invalid_condition = (height != 0) && (intersection_point.z < reference_point.z || intersection_point.z > reference_point.z + height);

                if (x_invalid_condition || y_invalid_condition || z_invalid_condition)
                {
                    max_t = INF;
                }
            }

            if ((min_t < 0.0 || min_t >= max_t))
            {
                min_t = max_t;
            }
        }
        else if (max_t >= INF && min_t > 0.0)
        {
            Vector3D intersection_point = r.origin_vec.VectorAddition(r.direction_vec.VectorScalarMultiply(min_t));

            double x_invalid_condition = (length != 0) && (intersection_point.x < reference_point.x || intersection_point.x > reference_point.x + length);
            double y_invalid_condition = (width != 0) && (intersection_point.y < reference_point.y || intersection_point.y > reference_point.y + width);
            double z_invalid_condition = (height != 0) && (intersection_point.z < reference_point.z || intersection_point.z > reference_point.z + height);

            if (x_invalid_condition || y_invalid_condition || z_invalid_condition)
            {
                min_t = INF;
            }
        }

        if (level == 0)
        {
            return min_t;
        }

        Color intersection_color = this->color;
        Vector3D intersection_point = r.origin_vec.VectorAddition(r.direction_vec.VectorScalarMultiply(min_t));

        Vector3D normalVect = calcNormal(intersection_point);

        double dotProduct = normalVect.VectorDotProduct(r.direction_vec.VectorScalarMultiply(-1.0));
        if (dotProduct < 0.0)
        {
            normalVect = normalVect.VectorScalarMultiply(-1.0);
        }

        ComputeLightShadow(this, r, myColor, level, intersection_point, normalVect, intersection_color, min_t);

        if (level >= recursionDepth)
        {
            return min_t;
        }

        ComputeColor(this, r, myColor, level, intersection_point, normalVect);

        return min_t;
    }
};
